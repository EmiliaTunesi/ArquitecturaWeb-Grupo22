package com.arquitecturaweb.ejercicioIntegrador3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioIntegrador3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
